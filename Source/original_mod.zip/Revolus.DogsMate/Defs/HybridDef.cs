﻿using RimWorld;
using System.Collections.Generic;
using System.Linq;
using Verse;

namespace Revolus.DogsMate {
    public class HybridHediff {
        public HediffDef hediffDef;
        public BodyPartDef bodyPartDef;
        public SimpleCurve severityCurve;
    }

    public class AnimalFertilityReduced : HediffDef {
    }

    public class HybridDef : Def {
        public List<AnimalGroupDef> parents = new List<AnimalGroupDef>();
        public List<AnimalGroupDef> children = new List<AnimalGroupDef>();

        public List<HybridHediff> childrenHediffs = new List<HybridHediff>();
        public List<HybridHediff> maleChildrenHediffs = new List<HybridHediff>();
        public List<HybridHediff> femaleChildrenHediffs = new List<HybridHediff>();

        public SimpleCurve fertilizationFailesIfGreaterThanZeroCurve;

        public override IEnumerable<string> ConfigErrors() {
            foreach (var item in base.ConfigErrors()) {
                yield return item;
            }

            if (this.parents.Count < 2) {
                yield return $"{nameof(HybridDef)}.{nameof(this.parents)} needs at least 2 items";
            } else if (this.parents.Distinct().Count() < this.parents.Count) {
                yield return $"{nameof(HybridDef)}.{nameof(this.parents)} must not have duplicated elements";
            }

            if (this.children.Count < 1) {
                yield return $"{nameof(HybridDef)}.{nameof(this.children)} needs at least 1 item";
            }
        }

        private bool? _isUsable;

        public bool IsUsable {
            get {
                if (this is null) {
                    return false;
                }
                if (!this._isUsable.HasValue) {
                    this._isUsable = (
                        this.parents != null && this.parents.Where(p => p.IsUsable && p.canMate).Distinct().Count() >= 2 &&
                        this.children != null && this.children.Any(p => p.IsUsable)
                    );
                }
                return this._isUsable.Value;
            }
        }

        private static IReadOnlyDictionary<AnimalGroupDef, IReadOnlyDictionary<AnimalGroupDef, IReadOnlyList<HybridDef>>> _dict;

        public static IReadOnlyDictionary<AnimalGroupDef, IReadOnlyDictionary<AnimalGroupDef, IReadOnlyList<HybridDef>>> LookupDict {
            get {
                if (_dict is null) {
                    _dict = (
                        DefDatabase<HybridDef>.AllDefsListForReading.
                        Where(def => def.IsUsable).
                        Select(h => (
                            h.parents.
                            Where(a => a.IsUsable).
                            Cross().
                            Where(ab => ab.Item1 != ab.Item2).
                            Select(ab => (a: ab.Item1, b: ab.Item2, h))
                        )).
                        SelectMany(x => x).
                        GroupBy(x => x.a).
                        ToDictionary(g => g.Key, g => (
                            g.
                            GroupBy(x => x.b).
                            ToDictionary(g2 => g2.Key, g2 => (
                                g2.
                                Select(x => x.h).
                                Distinct().
                                ToList().
                                AsReadOnlyList()
                            )).
                            AsReadOnlyDict()
                        )).
                        AsReadOnlyDict()
                    );
                }
                return _dict;
            }
        }

        public static bool TryGetHybrids(AnimalGroupDef group, out IReadOnlyDictionary<AnimalGroupDef, IReadOnlyList<HybridDef>> hybrids) {
            if (group is null) {
                hybrids = default;
                return false;
            } else {
                return LookupDict.TryGetValue(group, out hybrids);
            }
        }

        private static readonly Dictionary<PawnKindDef, IReadOnlyDictionary<AnimalGroupDef, IReadOnlyList<HybridDef>>> kindToHybrids =
            new Dictionary<PawnKindDef, IReadOnlyDictionary<AnimalGroupDef, IReadOnlyList<HybridDef>>>();

        public static bool TryGetHybrids(PawnKindDef kindDef, out IReadOnlyDictionary<AnimalGroupDef, IReadOnlyList<HybridDef>> hybrids) {
            if (!kindToHybrids.TryGetValue(kindDef, out hybrids)) {
                if (AnimalGroupDef.TryGetGroups(kindDef, out var groups)) {
                    hybrids = (
                        groups.
                        Select(a => TryGetHybrids(a, out var d) ? d : null).
                        Where(d => d != null).
                        SelectMany(x => x).
                        GroupBy(kv => kv.Key).
                        ToDictionary(g => g.Key, g => (
                            g.
                            Select(kv => kv.Value.Where(h => h.IsUsable)).
                            SelectMany(x => x).
                            Distinct().
                            ToList().
                            AsReadOnlyList()
                        )).
                        AsReadOnlyDict()
                    );
                }
                kindToHybrids.Add(kindDef, hybrids);
            }
            return hybrids != null && hybrids.Count > 0;
        }

        public static bool TryGetHybrids(ThingDef thingDef, out IReadOnlyDictionary<AnimalGroupDef, IReadOnlyList<HybridDef>> hybrids) =>
            TryGetHybrids(thingDef?.race?.AnyPawnKind, out hybrids);

        public static bool TryGetHybrids(Pawn pawn, out IReadOnlyDictionary<AnimalGroupDef, IReadOnlyList<HybridDef>> hybrids) =>
            TryGetHybrids(pawn?.kindDef, out hybrids);

        public static bool TryGetHybrids(Thing thing, out IReadOnlyDictionary<AnimalGroupDef, IReadOnlyList<HybridDef>> hybrids) =>
            TryGetHybrids(thing as Pawn, out hybrids);

        public static bool TryGetHybrids(Def def, out IReadOnlyDictionary<AnimalGroupDef, IReadOnlyList<HybridDef>> hybrids) {
            if (def is PawnKindDef kindDef) {
                return TryGetHybrids(kindDef, out hybrids);
            } else if (def is ThingDef thingDef) {
                return TryGetHybrids(thingDef, out hybrids);
            } else {
                hybrids = default;
                return false;
            }
        }

        public static bool TryGetHybrids(StatRequest req, out IReadOnlyDictionary<AnimalGroupDef, IReadOnlyList<HybridDef>> hybrids) {
            if (req.Pawn != null) {
                return TryGetHybrids(req.Pawn, out hybrids);
            } else if (req.Thing != null) {
                return TryGetHybrids(req.Thing, out hybrids);
            } else if (req.Def != null) {
                return TryGetHybrids(req.Def, out hybrids);
            } else {
                hybrids = default;
                return false;
            }
        }

        private static IReadOnlyDictionary<PawnKindDef, IReadOnlyList<PawnKindDef>> _hybridParents;

        public static IReadOnlyDictionary<PawnKindDef, IReadOnlyList<PawnKindDef>> HybridParents {
            get {
                if (_hybridParents is null) {
                    _hybridParents = (
                        DefDatabase<HybridDef>.AllDefsListForReading.
                        Where(h => h != null).
                        Select(h => (
                            h.children.
                            Where(a => a.IsUsable).
                            Select(a => a.pawnKinds.Where(c => c != null)).
                            SelectMany(x => x).
                            Select(c => (c, a: h.parents.Where(a => a.IsUsable)))
                        )).
                        SelectMany(x => x).
                        GroupBy(kv => kv.c).
                        ToDictionary(g => g.Key, g => (
                            g.
                            Select(x => x.a).
                            SelectMany(a => a).
                            Select(a => a.pawnKinds.Where(p => p != null)).
                            SelectMany(p => p).
                            Distinct().
                            ToList().
                            AsReadOnlyList()
                        ))
                    );
                }
                return _hybridParents;
            }
        }

        public static bool TryGetParents(PawnKindDef childDef, out IReadOnlyList<PawnKindDef> parents) {
            if (childDef is null) {
                parents = default;
                return false;
            }

            return HybridParents.TryGetValue(childDef, out parents);
        }

        public static bool TryGetHybrids(PawnKindDef a, PawnKindDef b, out IReadOnlyList<HybridDef> hybrids) {
            if (a == b || !TryGetHybrids(a, out var aHybridDict) || !AnimalGroupDef.TryGetGroups(b, out var bGroupsList)) {
                hybrids = default;
                return false;
            }

            hybrids = (
                bGroupsList.
                Select(bGroup => aHybridDict.TryGetValue(bGroup, out var l) ? l : null).
                Where(l => l != null).
                SelectMany(x => x).
                Distinct().
                ToList()
            );
            return hybrids.Count > 0;
        }
    }
}
