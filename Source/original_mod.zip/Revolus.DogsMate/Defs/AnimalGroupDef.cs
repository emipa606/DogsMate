﻿using RimWorld;
using System.Collections.Generic;
using System.Linq;
using Verse;

namespace Revolus.DogsMate {
    public class AnimalGroupDef : Def {
        public List<PawnKindDef> pawnKinds = new List<PawnKindDef>();
        public bool canMate = true;

        private bool? _isUsable;

        public bool IsUsable {
            get {
                if (this is null) {
                    return false;
                }
                if (!this._isUsable.HasValue) {
                    this._isUsable = this.pawnKinds != null && this.pawnKinds.Where(p => p != null).Count() > 0;
                }
                return this._isUsable.Value;
            }
        }

        private static IReadOnlyDictionary<PawnKindDef, IReadOnlyCollection<AnimalGroupDef>> _dict;

        public static IReadOnlyDictionary<PawnKindDef, IReadOnlyCollection<AnimalGroupDef>> LookupDict {
            get {
                if (_dict is null) {
                    _dict = (
                        DefDatabase<AnimalGroupDef>.AllDefsListForReading.
                        Where(def => def.IsUsable).
                        Select(def => def.pawnKinds.Where(p => p != null).Select(pawnKind => (pawnKind, def))).
                        SelectMany(kv => kv).
                        GroupBy(kv => kv.pawnKind).
                        ToDictionary(
                            g => g.Key,
                            g => g.Select(x => x.def).Distinct().ToArray().AsReadOnlyArray()
                        ).
                        AsReadOnlyDict()
                    );
                }
                return _dict;
            }
        }

        public static bool TryGetGroups(PawnKindDef kindDef, out IReadOnlyCollection<AnimalGroupDef> groups) {
            if (kindDef != null) {
                return LookupDict.TryGetValue(kindDef, out groups);
            } else {
                groups = default;
                return false;
            }
        }

        public static bool TryGetGroups(ThingDef thingDef, out IReadOnlyCollection<AnimalGroupDef> groups) =>
            TryGetGroups(thingDef?.race?.AnyPawnKind, out groups);

        public static bool TryGetGroups(Pawn pawn, out IReadOnlyCollection<AnimalGroupDef> groups) =>
            TryGetGroups(pawn?.kindDef, out groups);

        public static bool TryGetGroups(Thing thing, out IReadOnlyCollection<AnimalGroupDef> groups) =>
            TryGetGroups(thing as Pawn, out groups);

        public static bool TryGetGroups(Def def, out IReadOnlyCollection<AnimalGroupDef> groups) {
            if (def is PawnKindDef kindDef) {
                return TryGetGroups(kindDef, out groups);
            } else if (def is ThingDef thingDef) {
                return TryGetGroups(thingDef, out groups);
            } else if (def is AnimalGroupDef animalGroupDef) {
                groups = new[] { animalGroupDef };
                return true;
            } else {
                groups = default;
                return false;
            }
        }

        public static bool TryGetGroups(StatRequest req, out IReadOnlyCollection<AnimalGroupDef> groups) {
            if (req.Pawn != null) {
                return TryGetGroups(req.Pawn, out groups);
            } else if (req.Thing != null) {
                return TryGetGroups(req.Thing, out groups);
            } else if (req.Def != null) {
                return TryGetGroups(req.Def, out groups);
            } else {
                groups = default;
                return false;
            }
        }
    }
}
